import datetime
from collections import namedtuple

import bs4
import requests

InnerBlock = namedtuple('Block', 'title,price,currency,date,url')


class Block(InnerBlock):
    def __str__(self):
        return f'{self.title}\t{self.price} {self.currency}\t{self.date}\t{self.url}'


class AvitoParser:

    def __init__(self):
        self.session = requests.Session()
        self.session.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36',
            'Accept-Language': 'ru'
        }

    def get_page(self, page: int = None):
        params = {
            'radius': 0,
            'user': 1
        }
        if page and page > 1:
            params['p'] = page

        url = 'https://www.avito.ru/moskva/avtomobili/bmw/x5'
        r = self.session.get(url, params=params)
        return r.text

    def parse_block(self, item):
        # linkni olish
        url_block = item.select_one('a.snippet-link')
        href = url_block.get('href')
        if href:
            url = 'https://www.avito.ru' + href
        else:
            url = None

        # ismni olish
        title_block = item.select_one('h3.snippet-title a')
        title = title_block.string.strip()

        # pulini va turini olish
        price_block = item.select_one('div.snippet-price-row span')
        price = price_block.get_text().split('\n')[1][1:]

    def get_blocks(self):
        text = self.get_page(page=2)
        soup = bs4.BeautifulSoup(text, 'lxml')

        # umumiy blokni olish
        container = soup.select('div.description.item_table-description')
        for item in container:
            block = self.parse_block(item=item)
            # print(block)


def main():
    p = AvitoParser()
    p.get_blocks()


if __name__ == '__main__':
    main()