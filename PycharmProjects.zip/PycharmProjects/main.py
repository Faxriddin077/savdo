from telegram import (ReplyKeyboardMarkup, ReplyKeyboardRemove, Bot, Update)
from telegram.ext import (Updater, CommandHandler, MessageHandler, Filters, ConversationHandler, CallbackQueryHandler)
# from dbhelper import DBHelper

# db = DBHelper

STATE_LOGIN = 0
STATE_LOGIN_TEST = 1
STATE_ADMIN = 2

bosh_buttons = ReplyKeyboardMarkup([['Махсулот сотиш'], ['Омбор'], ['Махсулот айланмаси'], ['Логин қўшиш']],
                                   resize_keyboard=True,
                                   one_time_keyboard=True)
turlar = ReplyKeyboardMarkup([['Газобетонный блок\n 600x100x300', 'Газобетонный блок\n 600x200x300'],
                              ['Газобетонный блок\n 600x300x300', 'Газобетонный блок\n 600x400x300'], ['Орқага']],
                             one_time_keyboard=True, resize_keyboard=True)


def start(update, context):
    reply_keyboard = [['login']]
    update.message.reply_html(
        'ombor ', reply_markup=ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True, resize_keyboard=True))
    return STATE_LOGIN


def login(update, context):
    update.message.reply_html('Илтимос логинни киритинг', reply_markup=ReplyKeyboardRemove(remove_keyboard=True))
    return STATE_LOGIN_TEST


def login_test(update, context):
    text = update.message.text
    if text != '/start':
        print(text)
        update.message.reply_html('Ассалому алайкум хурматли <b>{}</b>'.format(update.message.from_user.first_name), reply_markup=bosh_buttons)
    return STATE_ADMIN


def max_qoshish(update, context):
    update.message.reply_html(
        ' max_sotish', reply_markup=turlar)


def max_sotish(update, context):
    update.message.reply_html(
        ' max_sotish', reply_markup=turlar)


def ombor(update, context):
    reply_keyboard = [['Махсулот қўшиш', 'Қолдиқ']]
    update.message.reply_html(
        'ombor ', reply_markup=ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True, resize_keyboard=True))


def max_aylanmasi(update, context):
    update.message.reply_html(
        'max aylanmasi ', reply_markup=turlar)


def ortga(update, context):
    update.message.reply_html(
        'fffff', reply_markup=bosh_buttons)


def qoldiq(update, context):
    update.message.reply_html(
        'qoldiwq', reply_markup=turlar)


def qosh(update, context):
    update.message.reply_html(
        'qoldiwq', reply_markup=turlar)
    text = update.message.text


def main():
    updater = Updater(
        token='1213085873:AAHrTL5xe89fpnRqpzWc4EPzhKMtEQw0lyg',
        use_context=True)
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            STATE_LOGIN: [MessageHandler(Filters.regex('^(login)$'), login)],
            STATE_LOGIN_TEST: [MessageHandler(Filters.text, login_test)],
            STATE_ADMIN: [
                MessageHandler(Filters.regex('^(Махсулот қўшиш)$'), max_qoshish),
                MessageHandler(Filters.regex('^(Махсулот сотиш)$'), max_sotish),
                MessageHandler(Filters.regex('^(Омбор)$'), ombor),
                MessageHandler(Filters.regex('^(Махсулот айланмаси)$'), max_aylanmasi),
                MessageHandler(Filters.regex('^(Орқага)$'), ortga),
                MessageHandler(Filters.regex('^(Қолдиқ)$'), qoldiq),
                MessageHandler(Filters.regex('^(Логин қўшиш)$'), qosh),
            ]
        },
        fallbacks=[MessageHandler(Filters.text, start)],
    )
    dispatcher = updater.dispatcher
    dispatcher.add_handler(conv_handler)

    updater.start_polling()
    updater.idle()


main()
