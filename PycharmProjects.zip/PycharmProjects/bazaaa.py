# path = 'images/qish/bolshimerka/qish2.jpg'
# http_proxy = "45.76.160.191:8080"
# proxyDict = {
#               "http": http_proxy,
#             }
